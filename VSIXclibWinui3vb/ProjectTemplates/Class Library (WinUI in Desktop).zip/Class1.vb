﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports Microsoft.UI.Xaml.Controls

' To learn more about WinUI, the WinUI project structure,
' and more about our project templates, see: http://aka.ms/winui-project-info.

' default in VStudio is .Net 5, we change it to .Net 6 (LTS)
' if your WinUI3 app still uses .Net 5, try to change it to .Net 6, and if it leads you to error,
' change TargetFramework in app's.csproj:
' <TargetFramework>net6.0-windows10.0.19041.0</TargetFramework>
' (Vstudio probably change it to "net6.0-windows", without Windows version number)

Public Class Class1

End Class


